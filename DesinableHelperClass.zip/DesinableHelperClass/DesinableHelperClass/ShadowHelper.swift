//
//  ShadowHelper.swift
//  DesinableHelperClass
//
//  Created by prashant singh on 14/03/18.
//  Copyright © 2018 prashant singh. All rights reserved.
//

import UIKit

@IBDesignable class ShadowHelper : UIButton{
    
    @IBInspectable var cornerRdedius : CGFloat {
        get {
            return layer.cornerRadius
        }
        set {
           layer.cornerRadius = newValue
        }
    }
    
    @IBInspectable var borderWidth : CGFloat {
        get {
            return layer.borderWidth
        }
        set {
            layer.borderWidth = newValue
        }
    }
    
    @IBInspectable var borderColor : UIColor {
        get {
            if let color = layer.borderColor{
                return UIColor(cgColor: color)
            }
            return UIColor()
        }
        set {
            layer.borderColor = newValue.cgColor
        }
    }
    
    @IBInspectable var shadowOpacity : Float {
        get {
            return layer.shadowOpacity
        }
        set {
            layer.shadowOpacity = newValue
        }
    }
    
    @IBInspectable var shadowOffset : CGSize {
        get {
            return layer.shadowOffset
        }
        set {
            layer.shadowOffset = newValue
        }
    }
    
    @IBInspectable var shadowColor : CGColor?{
        get {
            if let color = layer.shadowColor{
                return color
            }
            return nil
        }
        set {
            layer.shadowColor = newValue
        }
    }
    
    @IBInspectable var shadowRedius : CGFloat{
        get {
            return layer.shadowRadius
        }
        set {
            layer.shadowRadius = newValue
        }
    }
}

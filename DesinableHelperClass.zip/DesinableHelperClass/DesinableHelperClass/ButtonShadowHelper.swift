//
//  ButtonShadowHelper.swift
//  DesinableHelperClass
//
//  Created by prashant singh on 15/03/18.
//  Copyright © 2018 prashant singh. All rights reserved.
//

import UIKit

class ButtonShadowHelper: NSObject {

}
